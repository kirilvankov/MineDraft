﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Minedraft.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
